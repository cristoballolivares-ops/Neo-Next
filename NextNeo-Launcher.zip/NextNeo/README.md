# Next Neo Launcher

Launcher nuevo, inspirado en la estética de Next Launcher 3D (cubo 3D, dock de cristal, neón cian).
Kotlin + Jetpack Compose, 100 % código propio, sin librerías nativas (funciona en ARM64 y 32 bits).

## Compilar
1. Abre la carpeta en Android Studio (versión reciente). Sincroniza Gradle.
2. Si pide ajustar versiones de AGP/Kotlin/Compose BOM, acepta la sugerencia.
3. Run en un dispositivo o emulador y, al lanzarlo, elige "Next Neo" como app de inicio.

## Uso
- Desliza horizontal: cubo 3D entre pantallas. Desliza hacia arriba o toca el botón de puntos: cajón de apps con búsqueda.
- Mantén pulsada una app: anclar al inicio, añadir al dock o ver información.
- Botón Inicio: vuelve a la primera pantalla y cierra el cajón.

## Datos técnicos
minSdk 29 · targetSdk/compileSdk 36 · edge-to-edge · icono adaptable y monocromo · atrás predictivo habilitado
