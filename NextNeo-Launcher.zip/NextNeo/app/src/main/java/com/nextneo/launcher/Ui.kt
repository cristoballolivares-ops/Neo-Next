package com.nextneo.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale
import kotlin.math.abs

val Neon = Color(0xFF38D6FF)
private val Ink = Color(0xFF050B1A)

@Composable
fun NeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, surface = Color(0xFF0B1730)), content = content)
}

@Composable
fun LauncherScreen(vm: LauncherViewModel, homeSignal: Int) {
    var drawerOpen by remember { mutableStateOf(false) }
    val byKey = remember(vm.apps) { vm.apps.associateBy { it.key } }
    val pinnedApps = vm.pinned.mapNotNull { byKey[it] }
    val dockApps = vm.dock.mapNotNull { byKey[it] }

    val pages: List<List<AppInfo>> = remember(pinnedApps) {
        val all = listOf(pinnedApps.take(8)) + pinnedApps.drop(8).chunked(16)
        if (all.size < 2) all + listOf(emptyList()) else all
    }
    val pagerState = rememberPagerState { pages.size }

    LaunchedEffect(homeSignal) {
        drawerOpen = false
        pagerState.animateScrollToPage(0)
    }
    BackHandler(enabled = drawerOpen) { drawerOpen = false }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -90f && !drawerOpen) drawerOpen = true },
                    onDragCancel = { },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0x66000814), Color.Transparent, Color(0xAA000814)))),
        )
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            HorizontalPager(pagerState, Modifier.weight(1f)) { page ->
                CubePage(pagerState, page) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                        if (page == 0) ClockHeader()
                        val apps = pages[page]
                        if (apps.isEmpty()) {
                            Text(
                                "Mantén pulsada una app en el cajón para anclarla aquí",
                                color = Color(0x99FFFFFF),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 24.dp, end = 24.dp),
                            )
                        } else {
                            AppGrid(apps) { app ->
                                AppIcon(app, onClick = { vm.launch(app) }) { dismiss -> AppMenu(vm, app, dismiss) }
                            }
                        }
                    }
                }
            }
            PageIndicator(pages.size, pagerState.currentPage)
            Dock(dockApps, vm, onOpenDrawer = { drawerOpen = true })
        }

        AnimatedVisibility(
            visible = drawerOpen,
            enter = fadeIn() + slideInVertically { it / 6 },
            exit = fadeOut() + slideOutVertically { it / 6 },
        ) {
            AppDrawer(vm, onClose = { drawerOpen = false })
        }
    }
}

@Composable
private fun CubePage(state: PagerState, page: Int, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val pos = (page - state.currentPage) - state.currentPageOffsetFraction
                cameraDistance = 16f * density
                transformOrigin = TransformOrigin(if (pos < 0f) 1f else 0f, 0.5f)
                rotationY = -90f * pos.coerceIn(-1f, 1f)
                alpha = if (abs(pos) >= 1f) 0f else 1f - 0.5f * abs(pos)
            },
        content = content,
    )
}

@Composable
private fun ClockHeader() {
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val timeFmt = remember { DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT) }
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEEE d MMM", Locale.getDefault()) }
    Column(Modifier.fillMaxWidth().padding(top = 36.dp, bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            now.format(timeFmt),
            color = Color.White,
            fontSize = 76.sp,
            fontWeight = FontWeight.ExtraLight,
            style = TextStyle(shadow = Shadow(Neon.copy(alpha = 0.7f), Offset.Zero, 28f)),
        )
        Text(
            now.format(dateFmt).replaceFirstChar { it.uppercase() },
            color = Color(0xCCFFFFFF),
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
private fun AppGrid(apps: List<AppInfo>, cell: @Composable (AppInfo) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        apps.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                row.forEach { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { cell(it) } }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIcon(
    app: AppInfo,
    showLabel: Boolean = true,
    onClick: () -> Unit,
    menu: @Composable (dismiss: () -> Unit) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    Box {
        Column(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        expanded = true
                    },
                )
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
            if (showLabel) {
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(68.dp).padding(top = 4.dp),
                    textAlign = TextAlign.Center,
                    style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 6f)),
                )
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menu { expanded = false }
        }
    }
}

@Composable
private fun AppMenu(vm: LauncherViewModel, app: AppInfo, dismiss: () -> Unit) {
    val pinned = app.key in vm.pinned
    val inDock = app.key in vm.dock
    DropdownMenuItem(
        text = { Text(if (pinned) "Quitar del inicio" else "Anclar al inicio") },
        onClick = { vm.togglePinned(app); dismiss() },
    )
    DropdownMenuItem(
        text = { Text(if (inDock) "Quitar del dock" else if (vm.dockFull) "Dock lleno" else "Añadir al dock") },
        enabled = inDock || !vm.dockFull,
        onClick = { vm.toggleDock(app); dismiss() },
    )
    DropdownMenuItem(
        text = { Text("Información de la app") },
        onClick = { vm.details(app); dismiss() },
    )
}

@Composable
private fun PageIndicator(count: Int, current: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            val selected = i == current
            val w by animateDpAsState(if (selected) 22.dp else 7.dp, label = "indicator")
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .height(7.dp)
                    .width(w)
                    .then(if (selected) Modifier.shadow(10.dp, CircleShape, ambientColor = Neon, spotColor = Neon) else Modifier)
                    .clip(CircleShape)
                    .background(if (selected) Neon else Color(0x55FFFFFF)),
            )
        }
    }
}

@Composable
private fun Dock(apps: List<AppInfo>, vm: LauncherViewModel, onOpenDrawer: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x14FFFFFF))))
            .border(1.dp, Brush.verticalGradient(listOf(Color(0x77FFFFFF), Color(0x2038D6FF))), shape)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        apps.forEach { app ->
            AppIcon(app, showLabel = false, onClick = { vm.launch(app) }) { dismiss -> AppMenu(vm, app, dismiss) }
        }
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Color(0x2238D6FF))
                .border(1.dp, Neon.copy(alpha = 0.6f), CircleShape)
                .clickable(onClick = onOpenDrawer),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(26.dp)) {
                for (i in 0..2) for (j in 0..2) {
                    drawCircle(
                        Color.White,
                        radius = size.width * 0.075f,
                        center = Offset(size.width * (0.17f + i * 0.33f), size.height * (0.17f + j * 0.33f)),
                    )
                }
            }
        }
    }
}

@Composable
private fun AppDrawer(vm: LauncherViewModel, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(vm.apps, query) {
        if (query.isBlank()) vm.apps else vm.apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xF2050B1A), Color(0xF7081A33))))
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 16.dp),
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 12.dp)
                .size(44.dp, 5.dp)
                .clip(CircleShape)
                .background(Color(0x66FFFFFF))
                .clickable(onClick = onClose),
        )
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Neon),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            decorationBox = { inner ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x1FFFFFFF))
                        .border(1.dp, Color(0x2238D6FF), RoundedCornerShape(24.dp))
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                ) {
                    if (query.isEmpty()) Text("Buscar apps", color = Color(0x99FFFFFF))
                    inner()
                }
            },
        )
        LazyVerticalGrid(columns = GridCells.Fixed(4), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered, key = { it.key }) { app ->
                Box(Modifier.padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                    AppIcon(app, onClick = { vm.launch(app); onClose() }) { dismiss -> AppMenu(vm, app, dismiss) }
                }
            }
        }
    }
}
